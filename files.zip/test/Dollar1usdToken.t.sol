// SPDX-License-Identifier: MIT
pragma solidity ^0.8.15;

import "forge-std/Test.sol";
import "../contracts/Dollar1usdToken.sol";

contract Dollar1usdTokenTest is Test {
    Dollar1usdToken token;
    address alice = address(0xA11Ce);

    function setUp() public {
        token = new Dollar1usdToken();
    }

    function testOwnerCanUpdateAuthorityAndMintProtected() public {
        // msg.sender is this contract (the test contract) which deployed the token, so is owner
        // set this test contract as authority (redundant since owner is allowed, but we test mapping as well)
        token.updateAuthorityStatus(address(this), true);

        uint256 before = token.balanceOf(alice);
        token.mintProtected(alice, 1_000 ether);
        assertEq(token.balanceOf(alice), before + 1_000 ether);
    }

    function testOnlyAuthorityCanMintProtected() public {
        // Try mintProtected from a non-authority account
        vm.prank(address(0xBEEF));
        vm.expectRevert("Dollar1usd: Caller is not authorized");
        token.mintProtected(alice, 1 ether);
    }
}