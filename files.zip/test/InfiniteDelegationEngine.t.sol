// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Test.sol";
import "../contracts/InfiniteDelegationEngine.sol";

contract InfiniteDelegationEngineTest is Test {
    InfiniteDelegationEngine ide;

    function setUp() public {
        ide = new InfiniteDelegationEngine();
    }

    function testCreateAndGetDelegationId() public {
        bytes32 id = ide.getDelegationId(address(this), 1);
        bytes32 id2 = keccak256(abi.encodePacked(address(this), uint256(1)));
        assertEq(id, id2);
    }
}