// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Test.sol";
import "../contracts/InfinityEngine.sol";

contract InfinityEngineTest is Test {
    InfinityEngine engine;

    function setUp() public {
        engine = new InfinityEngine();
    }

    function testOwnerIsDeployer() public {
        // The test contract deployed the engine, so it's the owner
        // owner() may be exposed via Ownable pattern — adjust if name differs
        // this is a smoke test to ensure deployment works
        assert(address(engine) != address(0));
    }
}