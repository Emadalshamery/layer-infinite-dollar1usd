// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Test.sol";
import "../contracts/Relayer/SovereignRelayer.sol";

contract SovereignRelayerTest is Test {
    SovereignRelayer relayer;

    function setUp() public {
        relayer = new SovereignRelayer(address(this));
    }

    function testSubmitTransactionIncrementsCounter() public {
        uint256 before = relayer.transactionCounter();
        relayer.submitTransaction(address(0x1234), 0, "", 21000, "");
        assertEq(relayer.transactionCounter(), before + 1);
    }
}